package com.example.taxifier.repository;

import com.example.taxifier.models.Taxi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaxiRepository  extends JpaRepository<Taxi, Long>
{
    Taxi findByEmail(String registrationNumber);
}
