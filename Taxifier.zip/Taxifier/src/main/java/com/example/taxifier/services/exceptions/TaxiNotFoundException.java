package com.example.taxifier.services.exceptions;

public class TaxiNotFoundException extends Throwable {
    public TaxiNotFoundException(String s) {
    }
}
