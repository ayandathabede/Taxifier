package com.example.taxifier.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@Builder(access = AccessLevel.PUBLIC)

public class UserDto
{
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String userType;
    private String idNumber;
    private String password;
    private LocalDateTime createdOn;
    private LocalDateTime updatedOn;
}
