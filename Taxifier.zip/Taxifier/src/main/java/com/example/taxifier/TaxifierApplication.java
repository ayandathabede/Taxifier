package com.example.taxifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxifierApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaxifierApplication.class, args);
    }

}
