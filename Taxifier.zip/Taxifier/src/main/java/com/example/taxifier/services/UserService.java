package com.example.taxifier.services;


import com.example.taxifier.dto.UserDto;
import com.example.taxifier.models.User;

import java.util.List;

public interface UserService
{
    List<UserDto> findAllUsers();

    UserDto findByEmail(String email);

     User saveUser(User user);

    UserDto findUserById(long userId);

    boolean findUserByEmail(String userEmail);

    void updateUser(UserDto user);

    User findUserrByEmail(String email);
}
