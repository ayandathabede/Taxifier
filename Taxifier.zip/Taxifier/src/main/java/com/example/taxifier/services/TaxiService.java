package com.example.taxifier.services;

import com.example.taxifier.dto.TaxiDto;
import com.example.taxifier.models.Taxi;
import com.example.taxifier.dto.UserDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface TaxiService
{

    List<TaxiDto> getAllTaxis();

    List<TaxiDto> getAlllTaxis();

    Taxi saveTaxi(Taxi taxi);

    void updateTaxi(TaxiDto updatedTaxi);

    void deleteTaxi(Long id);

    TaxiDto findTaxiByEmail(String taxiEmail);

    boolean findByEmail(String email);
}
