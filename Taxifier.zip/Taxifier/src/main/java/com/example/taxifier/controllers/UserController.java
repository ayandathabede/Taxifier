package com.example.taxifier.controllers;

import com.example.taxifier.dto.UserDto;
import com.example.taxifier.models.User;
import com.example.taxifier.services.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller
public class UserController
{
    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/users")
    public  String listUsers(Model model)
    {
        List<UserDto> users = userService.findAllUsers();
        model.addAttribute("users",users);
        return "user-home-page";
    }

    @GetMapping("/users/login")
    public String userLogin(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "login";
    }

    @GetMapping("/users/incorrect-email")
    public String incorrectEmail(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "user-incorrect-email";
    }
    @GetMapping("/users/incorrect-password")
    public String incorrectPassword(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "user-incorrect-password";
    }


    @GetMapping("/users/user-email-exists-page")
    public String userEmailExistsPage(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "user-email-exists-page";
    }

    @PostMapping("/users/login")
    public String userLogin(@ModelAttribute("user") UserDto userDto, HttpSession session) {
        UserDto existingUser = userService.findByEmail(userDto.getEmail());
        if (existingUser != null) {
            if (existingUser.getPassword().equals(userDto.getPassword())) {
                if (existingUser.getUserType().equalsIgnoreCase("taxi_driver")) {
                    session.setAttribute("driverName", existingUser.getFirstName());
                    session.setAttribute("driverId", existingUser.getId());
                    session.setAttribute("driverEmail", existingUser.getEmail());
                    return "redirect:/users/driver-dashboard";
                } else if (existingUser.getUserType().equalsIgnoreCase("customer")) {
                    session.setAttribute("customerId", existingUser.getId());
                    session.setAttribute("customerName", existingUser.getFirstName());
                    session.setAttribute("customerEmail", existingUser.getEmail());
                    return "redirect:/users/customer-dashboard";
                }
            } else {
                return "redirect:/users/incorrect-password";
            }
        }

        return "redirect:/users/incorrect-email";
    }


    @GetMapping("/users/signup")
    public String userSignUp(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "sign-up";
    }

    @GetMapping("/users/forgot-password")
    public String userForgotPassword(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "forgot-password";
    }
    @GetMapping("/users/password-sent-successfully")
    public String userEmailSent(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "email-sent-successful";
    }

    @PostMapping("/users/forgot-password")
    public ModelAndView forgotPassword(@RequestParam("email") String email) {
        User user =userService.findUserrByEmail(email);
        String password = user != null ? user.getPassword() : "";

        try {
            // Elastic Email API URL
            URL url = new URL("https://api.elasticemail.com/v2/email/send");

            // Elastic Email API Key
            String apiKey = "B4D92A3DA115B37E7750DF3592BD768D1693B0F6C256F4CF69E73AA6CE2BAB79231981A4DB8263FC32DB72FD465F5165";

            // Construct the request body
            String emailData = "apikey=" + apiKey +
                    "&from=kgaogeloandy27@gmail.com" +
                    "&to=" + email +
                    "&subject=Requested Account Password (CHECK SPAM MAIL)" +
                    "&bodyText=Your Password is :" + password;

            // Set up HTTP connection
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setDoOutput(true);

            // Encode the request body
            byte[] postData = emailData.getBytes(StandardCharsets.UTF_8);
            connection.setRequestProperty("Content-Length", String.valueOf(postData.length));

            // Send the request
            try (DataOutputStream wr = new DataOutputStream(connection.getOutputStream())) {
                wr.write(postData);
            }

            // Read the response
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                String inputLine;
                StringBuilder response = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                // Print the response
                System.out.println(response.toString());
            }

            // Close the connection
            connection.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new ModelAndView("email-sent-successful");
    }
    @GetMapping("/users/customer-dashboard")
    public String customerDashboard(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "customer-dashboard";
    }
    @GetMapping("/users/driver-dashboard")
    public String driverDashboard(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "driver-dashboard";
    }

    @GetMapping("/users/driver-queue-taxi")
    public String driverQueueTaxi(Model model)
    {
        User user = new User();
        model.addAttribute("user",user);
        return "driver-queue-taxi";
    }

    @PostMapping("/users/signup")
    public String createUserAccount(@ModelAttribute("user") User user, RedirectAttributes redirectAttributes) {

        boolean emailExists = userService.findUserByEmail(user.getEmail());
        if (emailExists) {
            redirectAttributes.addFlashAttribute("message", "Email already exists");
            return "redirect:user-email-exists-page";
        } else {
            userService.saveUser(user);
            return "redirect:/users/login";
        }
    }


    @GetMapping("/users/{userId}/edit")
    public String ediUserForm(@PathVariable("userId")long userId,Model model)
    {
        UserDto user = userService.findUserById(userId);
        model.addAttribute("user",user);
        return "user-edit";
    }

    @GetMapping("/users/{userId}/edit/driver")
    public String driverEditProfile(@PathVariable("userId")long userId,Model model)
    {
        UserDto user = userService.findUserById(userId);
        model.addAttribute("user",user);
        return "driver-edit-profile";
    }

    @PostMapping("/users/{userId}/edit/driver")
    public String updateDriver(@PathVariable("userId") long userId,@ModelAttribute("user") UserDto user)
    {
        user.setId(userId);
        userService.updateUser(user);

        return "redirect:/users/driver-dashboard";
    }

    @PostMapping("/users/{userId}/edit")
    public String updateUser(@PathVariable("userId") long userId,@ModelAttribute("user") UserDto user)
    {
        user.setId(userId);
        userService.updateUser(user);

        return "redirect:/users/customer-dashboard";
    }
}
