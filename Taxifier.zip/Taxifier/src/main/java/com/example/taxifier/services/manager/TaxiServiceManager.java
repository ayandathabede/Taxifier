package com.example.taxifier.services.manager;

import com.example.taxifier.dto.TaxiDto;
import com.example.taxifier.dto.UserDto;
import com.example.taxifier.models.Taxi;
import com.example.taxifier.models.User;
import com.example.taxifier.repository.TaxiRepository;
import com.example.taxifier.repository.UserRepository;
import com.example.taxifier.services.TaxiService;
import com.example.taxifier.services.exceptions.TaxiNotFoundException;
import lombok.SneakyThrows;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaxiServiceManager implements TaxiService
{
    private TaxiRepository taxiRepository;

    public TaxiServiceManager(TaxiRepository taxiRepository)
    {
        this.taxiRepository = taxiRepository;
    }



    @Override
    public List<TaxiDto> getAllTaxis() {
        List<Taxi> taxis = taxiRepository.findAll();
        return taxis.stream().map((taxi) -> mapToTaxiDto(taxi)).collect(Collectors.toList());
    }

    @Override
    public List<TaxiDto> getAlllTaxis() {
        List<Taxi> taxis = taxiRepository.findAll();
        return taxis.stream().map((taxi) -> mapToTaxiDto(taxi)).collect(Collectors.toList());
    }



    @Override
    public Taxi saveTaxi(Taxi taxi) {

        return  taxiRepository.save(taxi);
    }

    @SneakyThrows
    @Override
    public TaxiDto findTaxiByEmail(String taxiEmail) {
        Taxi taxi = taxiRepository.findByEmail(taxiEmail);
        if (taxi == null) {
            throw new TaxiNotFoundException("Taxi not found with email: " + taxiEmail);
        }
        return mapToTaxiDto(taxi);
    }

    @Override
    public boolean findByEmail(String email) {
        Taxi taxi = taxiRepository.findByEmail(email);
        return taxi != null;
    }

    @Override
    public void updateTaxi(TaxiDto taxiDto) {
        Taxi existingTaxi = taxiRepository.findByEmail(taxiDto.getEmail());

        existingTaxi.setTaxiFare(taxiDto.getTaxiFare());
        existingTaxi.setTripAmount(taxiDto.getTripAmount());
        existingTaxi.setNumberOFCompletedTrip(taxiDto.getNumberOFCompletedTrip());
        existingTaxi.setNumberOfPassenger(taxiDto.getNumberOfPassenger());
        taxiRepository.save(existingTaxi);
    }

    private Taxi mapToTaxi(TaxiDto taxiDto) {
        return Taxi.builder()
                .id(taxiDto.getId())
                .email(taxiDto.getEmail())
                .phoneNumber(taxiDto.getPhoneNumber())
                .surname(taxiDto.getSurname())
                .timeSlot(taxiDto.getTimeSlot())
                .registrationNumber(taxiDto.getRegistrationNumber())
                .driverName(taxiDto.getDriverName())
                .taxiFare(taxiDto.getTaxiFare())
                .tripAmount(taxiDto.getTripAmount())
                .numberOFCompletedTrip(taxiDto.getNumberOFCompletedTrip())
                .numberOfPassenger(taxiDto.getNumberOfPassenger())
                .createdOn(taxiDto.getCreatedOn())
                .updatedOn(taxiDto.getUpdatedOn())
                .build();
    }



    @Override
    public void deleteTaxi(Long id) {

    }


    private TaxiDto mapToTaxiDto(Taxi taxi)
    {
        TaxiDto taxiDto = TaxiDto.builder()
                .id(taxi.getId())
                .email(taxi.getEmail())
                .phoneNumber(taxi.getPhoneNumber())
                .surname(taxi.getSurname())
                .timeSlot(taxi.getTimeSlot())
                .registrationNumber(taxi.getRegistrationNumber())
                .driverName(taxi.getDriverName())
                .taxiFare(taxi.getTaxiFare())
                .tripAmount(taxi.getTripAmount())
                .numberOFCompletedTrip(taxi.getNumberOFCompletedTrip())
                .numberOfPassenger(taxi.getNumberOfPassenger())
                .createdOn(taxi.getCreatedOn())
                .updatedOn(taxi.getUpdatedOn())
                .build();

        return taxiDto;
    }
}
