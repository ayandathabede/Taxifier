package com.example.taxifier.dto;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Data
@Builder(access = AccessLevel.PUBLIC)

public class TaxiDto
{
    private Long id;
    private String email;
    private String driverName;
    private String surname;
    private String phoneNumber;
    private String registrationNumber;
    private int numberOFCompletedTrip;
    private int numberOfPassenger;
    private double taxiFare;
    private double tripAmount;
    private String timeSlot;
    private LocalDateTime createdOn;
    private LocalDateTime updatedOn;
}
