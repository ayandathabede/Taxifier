package com.example.taxifier.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Taxi-TBL")
public class Taxi
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_seq_generator")
    @SequenceGenerator(name="my_seq_generator", sequenceName="my_sequence", initialValue=1, allocationSize=1)
    private Long id;
    private String email;
    private String driverName;
    private String surname;
    private String phoneNumber;
    private String registrationNumber;
    private int numberOFCompletedTrip;
    private int numberOfPassenger;
    private double taxiFare;
    private String timeSlot;
    private double tripAmount;
    private double dailyMadeAmount;
    @CreationTimestamp
    private LocalDateTime createdOn;
    @UpdateTimestamp
    private LocalDateTime updatedOn;
}
