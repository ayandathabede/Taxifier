package  com.example.taxifier.controllers;

import com.example.taxifier.dto.TaxiDto;
import com.example.taxifier.dto.UserDto;
import com.example.taxifier.models.Taxi;
import com.example.taxifier.models.User;
import com.example.taxifier.services.TaxiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class TaxiController {

    public TaxiService taxiService;

    @Autowired
    public TaxiController(TaxiService taxiService)
    {
       this.taxiService = taxiService;
    }

    @GetMapping("/taxi/queue/form")
    public String  TaxiForm(Model model)
    {
        Taxi taxi = new Taxi();
        model.addAttribute("taxi",taxi);
        return "driver-queue-taxi";
    }

    @GetMapping("/taxi/view/queue")
    public String  TaxiViewQueue(Model model)
    {
        Taxi taxi = new Taxi();
        model.addAttribute("taxi",taxi);
        return "customer-view-queue";
    }

    @GetMapping("/taxi/view/past-trip")
    public String  TaxiViewPastTripCount(Model model)
    {
        Taxi taxi = new Taxi();
        model.addAttribute("taxi",taxi);
        return "customer-view-past-trip-count";
    }

    @GetMapping("/taxi/email-exist-page")
    public String  TaxiEmailPastExist(Model model)
    {
        Taxi taxi = new Taxi();
        model.addAttribute("taxi",taxi);
        return "email-exists-page";
    }

    @GetMapping("/taxi/view/{taxiEmail}/daily-made-amount")
    public String  TaxiViewDailyMadeAmount(@PathVariable("taxiEmail")String taxiEmail,Model model)
    {
        TaxiDto taxi = taxiService.findTaxiByEmail(taxiEmail);
        model.addAttribute("taxi",taxi);
        return "driver-view-daily-made-amount";
    }


    @GetMapping("/taxi/driver-dashboard")
    public String driverDashboard(Model model)
    {
        Taxi taxi = new Taxi();
        model.addAttribute("taxi",taxi);
        return "driver-dashboard";
    }
    @PostMapping("/taxi/add-queue")
    public String createTaxiAccount(@ModelAttribute("taxi") Taxi taxi, RedirectAttributes redirectAttributes) {
        boolean emailExists = taxiService.findByEmail(taxi.getEmail());
        if (emailExists) {
            // If email exists, redirect to a page indicating that the email already exists
            redirectAttributes.addFlashAttribute("message", "Email already exists");
            return "redirect:email-exist-page";
        } else {
            // If email doesn't exist, save the taxi details and redirect to the driver dashboard
            taxiService.saveTaxi(taxi);
            return "redirect:/taxi/driver-dashboard";
        }
    }


    @GetMapping("/taxi")
    public String getAllTaxis(Model model) {
        List<TaxiDto> taxis = taxiService.getAllTaxis();
        model.addAttribute("taxis",taxis);
        return "customer-view-queue";
    }

    @GetMapping("/taxi/trip-count")
    public String getAlllTaxis(Model model) {
        List<TaxiDto> taxis = taxiService.getAllTaxis();
        model.addAttribute("taxis",taxis);
        return "customer-view-past-trip-count";
    }

    @GetMapping("/taxi/driver-view-queue")
    public String getAllTaxiss(Model model) {
        List<TaxiDto> taxis = taxiService.getAllTaxis();
        model.addAttribute("taxis",taxis);
        return "driver-view-queue-taxi";
    }

    @GetMapping("/taxi/view/driver-queue")
    public String  driverView(Model model)
    {
        Taxi taxi = new Taxi();
        model.addAttribute("taxi",taxi);
        return "driver-view-queue-taxi";
    }

    @GetMapping("/taxi/{taxiEmail}/edit")
    public String editTaxiForm(@PathVariable("taxiEmail")String taxiEmail,Model model)
    {
        TaxiDto taxi = taxiService.findTaxiByEmail(taxiEmail);
        model.addAttribute("taxi",taxi);
        return "driver-depart";
    }


    @PostMapping("/taxi/{taxiEmail}/edit/driver")
    public String updateDriver(@PathVariable("taxiEmail") String  email,@ModelAttribute("taxi") TaxiDto taxi)
    {

        taxi.setEmail(email);
        taxiService.updateTaxi(taxi);

        return "redirect:/users/driver-dashboard";
    }




    @GetMapping("/new")
    public String showTaxiForm(Model model) {
        model.addAttribute("taxi", new Taxi());
        return "staxi-form"; // Return the name of the view to render
    }

    @PostMapping
    public String saveTaxi(@ModelAttribute Taxi taxi) {
        taxiService.saveTaxi(taxi);
        return "redirect:/taxis"; // Redirect to the list of taxis after saving
    }




    @GetMapping("/{id}/delete")
    public String deleteTaxi(@PathVariable Long id) {
        taxiService.deleteTaxi(id);
        return "redirect:/taxis"; // Redirect to the list of taxis after deleting
    }
}
