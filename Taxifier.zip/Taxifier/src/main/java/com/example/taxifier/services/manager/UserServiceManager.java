package com.example.taxifier.services.manager;

import com.example.taxifier.models.User;
import com.example.taxifier.dto.UserDto;
import com.example.taxifier.repository.UserRepository;
import com.example.taxifier.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import java.util.stream.Collectors;

@Service
public class UserServiceManager implements UserService {
    private UserRepository userRepository;

    public UserServiceManager(UserRepository userRepository)
    {
        this.userRepository = userRepository;
    }

    @Override
    public List<UserDto> findAllUsers() {
        List<User> users = userRepository.findAll();
        return users.stream().map((user) -> mapToUserDto(user)).collect(Collectors.toList());
    }

    @Override
    public UserDto findByEmail(String email) {
        User user = userRepository.findByEmail(email);
        if (user != null) {
            return UserDto.builder()
                    .email(user.getEmail())
                    .password(user.getPassword())
                    .userType(user.getUserType())
                    .firstName(user.getFirstName())
                    .id(user.getId())
                    .build();
        } else {
            return null;
        }
    }


    @Override
    public User saveUser(User user) {

       return  userRepository.save(user);
    }

    @Override
    public UserDto findUserById(long userId) {
        User user = userRepository.findById(userId).get();
        return mapToUserDto(user);
    }
    @Override
    public void updateUser(UserDto userDto) {
        User existingUser = userRepository.findById(userDto.getId())
                .orElseThrow(() -> new IllegalArgumentException("User not found with ID: " + userDto.getId()));


        existingUser.setEmail(userDto.getEmail());
        existingUser.setIdNumber(userDto.getIdNumber());
        existingUser.setLastName(userDto.getLastName());
        existingUser.setFirstName(userDto.getFirstName());
        userRepository.save(existingUser);
    }

    @Override
    public User findUserrByEmail(String email) {
        User user = userRepository.findByEmail(email);
        return user;
    }

    public boolean findUserByEmail(String userEmail) {
        User user = userRepository.findByEmail(userEmail);
        return user != null;
    }
    private User mapToUser(UserDto userDto) {
        return User.builder()
                .email(userDto.getEmail())
                .idNumber(userDto.getIdNumber())
                .lastName(userDto.getLastName())
                .email(userDto.getEmail())
                .firstName(userDto.getFirstName())
                .createdOn(userDto.getCreatedOn())
                .updatedOn(userDto.getUpdatedOn())
                .build();
    }


    private UserDto mapToUserDto(User user)
    {
        UserDto userDto = UserDto.builder()
                .id(user.getId())
                .email(user.getEmail())
                .userType(user.getUserType())
                .idNumber(user.getIdNumber())
                .lastName(user.getLastName())
                .password(user.getPassword())
                .firstName((user.getFirstName()))
                .createdOn(user.getCreatedOn())
                .updatedOn(user.getUpdatedOn())
                .build();

        return userDto;
    }
}
